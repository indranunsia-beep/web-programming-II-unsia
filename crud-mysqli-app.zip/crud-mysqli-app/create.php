<?php
// ============================================
//  create.php — CREATE: Tambah data baru
//  Menggunakan Prepared Statement (OOP mysqli)
// ============================================
require_once 'config/koneksi.php';

$pageTitle = 'Tambah Data';
$errors    = [];
$old       = []; // simpan input lama saat validasi gagal

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitasi input
    $nama  = trim(htmlspecialchars($_POST['nama']  ?? ''));
    $nim   = trim(htmlspecialchars($_POST['nim']   ?? ''));
    $prodi = trim(htmlspecialchars($_POST['prodi'] ?? ''));
    $email = trim(htmlspecialchars($_POST['email'] ?? ''));

    $old = compact('nama', 'nim', 'prodi', 'email');

    // Validasi server-side
    if (empty($nama))  $errors[] = 'Nama tidak boleh kosong.';
    if (empty($nim))   $errors[] = 'NIM tidak boleh kosong.';
    if (empty($prodi)) $errors[] = 'Program Studi tidak boleh kosong.';
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }

    // Cek NIM sudah ada
    if (empty($errors)) {
        $check = $db->prepare("SELECT id FROM mahasiswa WHERE nim = ?");
        $check->bind_param("s", $nim);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $errors[] = "NIM <strong>{$nim}</strong> sudah terdaftar.";
        }
        $check->close();
    }

    // Simpan ke database
    if (empty($errors)) {
        $stmt = $db->prepare(
            "INSERT INTO mahasiswa (nama, nim, prodi, email) VALUES (?, ?, ?, ?)"
        );

        if (!$stmt) {
            $errors[] = "Prepare failed: " . $db->error;
        } else {
            $emailVal = !empty($email) ? $email : null;
            $stmt->bind_param("ssss", $nama, $nim, $prodi, $emailVal);

            if ($stmt->execute()) {
                $stmt->close();
                $db->close();
                header("Location: index.php?msg=created");
                exit;
            } else {
                $errors[] = "Execute failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb" style="font-size:13px;">
        <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Data Mahasiswa</a></li>
        <li class="breadcrumb-item active">Tambah Data</li>
      </ol>
    </nav>

    <div class="card">
      <div class="card-header py-3 px-4">
        <div class="page-title"><i class="bi bi-person-plus-fill me-2 text-primary"></i>Tambah Data Mahasiswa</div>
        <div class="text-muted-sm mt-1">Semua input diproses dengan Prepared Statement</div>
      </div>
      <div class="card-body p-4">

        <!-- Error List -->
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Terdapat kesalahan:</strong>
          <ul class="mb-0 mt-2">
            <?php foreach ($errors as $e): ?>
              <li><?= $e ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <?php endif; ?>

        <form method="POST" action="create.php" novalidate>

          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
            <input type="text" name="nama" class="form-control"
              placeholder="Contoh: Budi Santoso"
              value="<?= htmlspecialchars($old['nama'] ?? '') ?>" required>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">NIM <span class="text-danger">*</span></label>
              <input type="text" name="nim" class="form-control"
                placeholder="Contoh: 20220001"
                value="<?= htmlspecialchars($old['nim'] ?? '') ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Program Studi <span class="text-danger">*</span></label>
              <select name="prodi" class="form-select" required>
                <option value="">-- Pilih Prodi --</option>
                <?php
                $prodis = ['Teknik Informatika', 'Sistem Informasi', 'Ilmu Komputer', 'Teknik Elektro'];
                foreach ($prodis as $p):
                    $sel = ($old['prodi'] ?? '') === $p ? 'selected' : '';
                ?>
                <option value="<?= $p ?>" <?= $sel ?>><?= $p ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label fw-semibold">Email <span class="text-muted fw-normal">(opsional)</span></label>
            <input type="email" name="email" class="form-control"
              placeholder="Contoh: budi@email.com"
              value="<?= htmlspecialchars($old['email'] ?? '') ?>">
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-save-fill me-2"></i>Simpan Data
            </button>
            <a href="index.php" class="btn btn-outline-secondary px-4">
              <i class="bi bi-arrow-left me-1"></i>Batal
            </a>
          </div>

        </form>
      </div>
    </div>

    <!-- Info Box -->
    <div class="card mt-3" style="background:#f8f9ff;border-color:#e0e0ef;">
      <div class="card-body py-3 px-4">
        <small class="text-muted d-flex align-items-center gap-2">
          <i class="bi bi-shield-check-fill text-primary"></i>
          Input diproses dengan <code>mysqli::prepare()</code> + <code>bind_param()</code> untuk mencegah SQL Injection.
        </small>
      </div>
    </div>

  </div>
</div>

<?php
$db->close();
require_once 'includes/footer.php';
?>
