<?php
// ============================================
//  Konfigurasi Koneksi Database — OOP mysqli
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_crud');

$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($db->connect_error) {
    die('<div class="alert alert-danger">
            <strong>Koneksi Gagal!</strong> ' . $db->connect_error . '
         </div>');
}

$db->set_charset('utf8mb4');
