<?php
// ============================================
//  edit.php — UPDATE: Edit data mahasiswa
//  Menggunakan Prepared Statement (OOP mysqli)
// ============================================
require_once 'config/koneksi.php';

$pageTitle = 'Edit Data';
$errors    = [];

// Validasi ID dari URL
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

// ── Proses POST (simpan perubahan) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id    = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $nama  = trim(htmlspecialchars($_POST['nama']  ?? ''));
    $nim   = trim(htmlspecialchars($_POST['nim']   ?? ''));
    $prodi = trim(htmlspecialchars($_POST['prodi'] ?? ''));
    $email = trim(htmlspecialchars($_POST['email'] ?? ''));

    // Validasi
    if (empty($nama))  $errors[] = 'Nama tidak boleh kosong.';
    if (empty($nim))   $errors[] = 'NIM tidak boleh kosong.';
    if (empty($prodi)) $errors[] = 'Program Studi tidak boleh kosong.';
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }

    // Cek NIM duplikat (boleh sama milik sendiri)
    if (empty($errors)) {
        $check = $db->prepare("SELECT id FROM mahasiswa WHERE nim = ? AND id != ?");
        $check->bind_param("si", $nim, $id);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $errors[] = "NIM <strong>{$nim}</strong> sudah digunakan mahasiswa lain.";
        }
        $check->close();
    }

    // Update ke database
    if (empty($errors)) {
        $stmt = $db->prepare(
            "UPDATE mahasiswa SET nama=?, nim=?, prodi=?, email=? WHERE id=?"
        );

        if (!$stmt) {
            $errors[] = "Prepare failed: " . $db->error;
        } else {
            $emailVal = !empty($email) ? $email : null;
            $stmt->bind_param("ssssi", $nama, $nim, $prodi, $emailVal, $id);

            if ($stmt->execute()) {
                $stmt->close();
                $db->close();
                header("Location: index.php?msg=updated");
                exit;
            } else {
                $errors[] = "Execute failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    // Kalau error, tetap tampilkan form dengan input lama
    $row = compact('id', 'nama', 'nim', 'prodi', 'email');

} else {
    // ── GET: Ambil data dari database ──
    $stmt = $db->prepare("SELECT * FROM mahasiswa WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        header("Location: index.php");
        exit;
    }

    $row = $result->fetch_assoc();
    $stmt->close();
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-7">

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb" style="font-size:13px;">
        <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Data Mahasiswa</a></li>
        <li class="breadcrumb-item active">Edit Data</li>
      </ol>
    </nav>

    <div class="card">
      <div class="card-header py-3 px-4 d-flex justify-content-between align-items-center">
        <div>
          <div class="page-title"><i class="bi bi-pencil-square me-2 text-warning"></i>Edit Data Mahasiswa</div>
          <div class="text-muted-sm mt-1">ID: #<?= $row['id'] ?></div>
        </div>
        <span class="badge bg-warning text-dark" style="font-family:'JetBrains Mono',monospace;">UPDATE</span>
      </div>
      <div class="card-body p-4">

        <!-- Error List -->
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Terdapat kesalahan:</strong>
          <ul class="mb-0 mt-2">
            <?php foreach ($errors as $e): ?>
              <li><?= $e ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <?php endif; ?>

        <form method="POST" action="edit.php" novalidate>
          <input type="hidden" name="id" value="<?= $row['id'] ?>">

          <div class="mb-3">
            <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
            <input type="text" name="nama" class="form-control"
              value="<?= htmlspecialchars($row['nama']) ?>" required>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">NIM <span class="text-danger">*</span></label>
              <input type="text" name="nim" class="form-control"
                value="<?= htmlspecialchars($row['nim']) ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Program Studi <span class="text-danger">*</span></label>
              <select name="prodi" class="form-select" required>
                <?php
                $prodis = ['Teknik Informatika', 'Sistem Informasi', 'Ilmu Komputer', 'Teknik Elektro'];
                foreach ($prodis as $p):
                    $sel = $row['prodi'] === $p ? 'selected' : '';
                ?>
                <option value="<?= $p ?>" <?= $sel ?>><?= $p ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label fw-semibold">Email</label>
            <input type="email" name="email" class="form-control"
              value="<?= htmlspecialchars($row['email'] ?? '') ?>">
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-warning px-4 text-dark fw-semibold">
              <i class="bi bi-arrow-clockwise me-2"></i>Update Data
            </button>
            <a href="index.php" class="btn btn-outline-secondary px-4">
              <i class="bi bi-arrow-left me-1"></i>Batal
            </a>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>

<?php
$db->close();
require_once 'includes/footer.php';
?>
