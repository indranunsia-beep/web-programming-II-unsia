<?php
// ============================================
//  index.php — READ: Tampilkan semua data
// ============================================
require_once 'config/koneksi.php';

$pageTitle = 'Data Mahasiswa';

// Ambil semua data
$result = $db->query("SELECT * FROM mahasiswa ORDER BY id ASC");

if (!$result) {
    $queryError = "Query Error: " . $db->error;
}

// Pesan flash dari redirect
$msg = $_GET['msg'] ?? '';

require_once 'includes/header.php';
?>

<!-- Flash Messages -->
<?php if ($msg === 'created'): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="bi bi-check-circle-fill me-2"></i><strong>Berhasil!</strong> Data mahasiswa baru berhasil ditambahkan.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php elseif ($msg === 'updated'): ?>
  <div class="alert alert-info alert-dismissible fade show" role="alert">
    <i class="bi bi-pencil-fill me-2"></i><strong>Diperbarui!</strong> Data mahasiswa berhasil diubah.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php elseif ($msg === 'deleted'): ?>
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    <i class="bi bi-trash-fill me-2"></i><strong>Dihapus!</strong> Data mahasiswa berhasil dihapus.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<!-- Error Query -->
<?php if (isset($queryError)): ?>
  <div class="alert alert-danger">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($queryError) ?>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center py-3 px-4">
    <div>
      <div class="page-title"><i class="bi bi-people-fill me-2 text-primary"></i>Data Mahasiswa</div>
      <div class="text-muted-sm mt-1">Total: <?= $result ? $result->num_rows : 0 ?> record</div>
    </div>
    <a href="create.php" class="btn btn-primary btn-sm px-3">
      <i class="bi bi-plus-lg me-1"></i>Tambah Data
    </a>
  </div>
  <div class="card-body p-0">
    <?php if ($result && $result->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
          <tr>
            <th class="ps-4" style="width:50px;">#</th>
            <th>Nama Lengkap</th>
            <th>NIM</th>
            <th>Program Studi</th>
            <th>Email</th>
            <th>Dibuat</th>
            <th class="text-center pe-4" style="width:130px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td class="ps-4 text-muted-sm"><?= $no++ ?></td>
            <td class="fw-600"><?= htmlspecialchars($row['nama']) ?></td>
            <td class="text-muted-sm"><?= htmlspecialchars($row['nim']) ?></td>
            <td><span class="badge-prodi"><?= htmlspecialchars($row['prodi']) ?></span></td>
            <td class="text-muted-sm"><?= htmlspecialchars($row['email'] ?? '-') ?></td>
            <td class="text-muted-sm"><?= date('d M Y', strtotime($row['created_at'])) ?></td>
            <td class="text-center pe-4">
              <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm me-1" title="Edit">
                <i class="bi bi-pencil-fill"></i>
              </a>
              <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" title="Hapus">
                <i class="bi bi-trash-fill"></i>
              </a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
      <i class="bi bi-inbox" style="font-size:48px;color:#ccc;"></i>
      <p class="mt-3 text-muted">Belum ada data. <a href="create.php">Tambah sekarang</a></p>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php
$result && $result->free();
$db->close();
require_once 'includes/footer.php';
?>
