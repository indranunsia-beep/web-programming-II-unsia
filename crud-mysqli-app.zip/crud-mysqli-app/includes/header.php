<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?? 'CRUD Mahasiswa' ?> — Pemrograman Web II</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <style>
    :root {
      --primary: #6c63ff;
      --success: #43e97b;
      --danger: #ff6584;
      --warning: #ffd93d;
    }
    body { font-family: 'Inter', sans-serif; background: #f0f2ff; min-height: 100vh; }
    .navbar-brand { font-weight: 700; letter-spacing: -0.02em; }
    .navbar { background: #fff; border-bottom: 1px solid #e0e0ef; box-shadow: 0 2px 16px rgba(108,99,255,0.07); }
    .nav-link.active { color: var(--primary) !important; font-weight: 600; }
    .card { border: 1px solid #e0e0ef; border-radius: 14px; box-shadow: 0 2px 16px rgba(108,99,255,0.06); }
    .card-header { border-radius: 14px 14px 0 0 !important; border-bottom: 1px solid #e0e0ef; background: #fafaff; }
    .btn-primary { background: var(--primary); border-color: var(--primary); }
    .btn-primary:hover { background: #5a52e0; border-color: #5a52e0; }
    .table th { font-size: 12px; text-transform: uppercase; letter-spacing: 0.08em; color: #888; font-weight: 600; }
    .badge-prodi { background: rgba(108,99,255,0.1); color: var(--primary); font-weight: 500; border-radius: 6px; padding: 3px 10px; font-size: 12px; }
    .page-title { font-size: 22px; font-weight: 700; letter-spacing: -0.02em; }
    .text-muted-sm { font-size: 13px; color: #999; font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand text-primary" href="index.php">
      <i class="bi bi-database-fill me-2"></i>CRUD<span class="text-muted fw-normal">App</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php"><i class="bi bi-table me-1"></i>Data</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'create.php' ? 'active' : '' ?>" href="create.php"><i class="bi bi-plus-circle me-1"></i>Tambah</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4">
