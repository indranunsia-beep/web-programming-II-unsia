
</div><!-- /container -->

<footer class="text-center py-4 mt-4" style="font-size:12px;color:#bbb;font-family:'JetBrains Mono',monospace;">
  Tugas Proyek — Pemrograman Web II &nbsp;|&nbsp; mysqli OOP Style &nbsp;|&nbsp; 2026
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
