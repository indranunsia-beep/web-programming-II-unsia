<?php
// ============================================
//  delete.php — DELETE: Hapus data mahasiswa
//  Halaman konfirmasi sebelum hapus
// ============================================
require_once 'config/koneksi.php';

$pageTitle = 'Hapus Data';

// Validasi ID
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT)
   ?? filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    header("Location: index.php");
    exit;
}

// ── Proses POST (konfirmasi hapus) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $stmt = $db->prepare("DELETE FROM mahasiswa WHERE id = ?");

    if (!$stmt) {
        die("Prepare failed: " . $db->error);
    }

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        $db->close();
        header("Location: index.php?msg=deleted");
        exit;
    } else {
        die("Execute failed: " . $stmt->error);
    }
}

// ── GET: Ambil data untuk konfirmasi ──
$stmt = $db->prepare("SELECT * FROM mahasiswa WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php");
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-lg-6">

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb" style="font-size:13px;">
        <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Data Mahasiswa</a></li>
        <li class="breadcrumb-item active">Hapus Data</li>
      </ol>
    </nav>

    <div class="card border-danger">
      <div class="card-header py-3 px-4" style="background:#fff5f5;border-color:#f5c6cb;">
        <div class="page-title text-danger">
          <i class="bi bi-exclamation-triangle-fill me-2"></i>Konfirmasi Hapus Data
        </div>
        <div class="text-muted-sm mt-1">Tindakan ini tidak dapat dibatalkan.</div>
      </div>
      <div class="card-body p-4">

        <p class="text-muted mb-3">Anda akan menghapus data berikut secara permanen:</p>

        <!-- Data Preview -->
        <div class="table-responsive mb-4">
          <table class="table table-bordered" style="font-size:14px;">
            <tr><th style="width:130px;background:#fafafa;">ID</th><td class="font-monospace">#<?= $row['id'] ?></td></tr>
            <tr><th style="background:#fafafa;">Nama</th><td><strong><?= htmlspecialchars($row['nama']) ?></strong></td></tr>
            <tr><th style="background:#fafafa;">NIM</th><td><?= htmlspecialchars($row['nim']) ?></td></tr>
            <tr><th style="background:#fafafa;">Prodi</th><td><?= htmlspecialchars($row['prodi']) ?></td></tr>
            <tr><th style="background:#fafafa;">Email</th><td><?= htmlspecialchars($row['email'] ?? '-') ?></td></tr>
          </table>
        </div>

        <!-- Tombol Aksi -->
        <div class="d-flex gap-2">
          <form method="POST" action="delete.php?id=<?= $row['id'] ?>">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <button type="submit" name="confirm_delete" value="1" class="btn btn-danger px-4">
              <i class="bi bi-trash-fill me-2"></i>Ya, Hapus Sekarang
            </button>
          </form>
          <a href="index.php" class="btn btn-outline-secondary px-4">
            <i class="bi bi-arrow-left me-1"></i>Batal
          </a>
        </div>

      </div>
    </div>

  </div>
</div>

<?php
$db->close();
require_once 'includes/footer.php';
?>
