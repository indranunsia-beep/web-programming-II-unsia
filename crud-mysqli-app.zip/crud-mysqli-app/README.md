# 📦 Aplikasi Mini CRUD — mysqli OOP Style
**Tugas Proyek Pemrograman Web II**

Aplikasi manajemen data mahasiswa berbasis web menggunakan PHP & MySQL dengan koneksi **mysqli Object-Oriented Style** dan keamanan **Prepared Statement**.

---

## 🗂️ Struktur Project
```
crud-mysqli-app/
├── config/
│   └── koneksi.php       # Koneksi database OOP mysqli
├── includes/
│   ├── header.php        # Template header (navbar, CSS)
│   └── footer.php        # Template footer (JS)
├── index.php             # READ  — Tampilkan semua data
├── create.php            # CREATE — Form tambah data baru
├── edit.php              # UPDATE — Form edit data
├── delete.php            # DELETE — Konfirmasi & hapus data
├── database.sql          # DDL + data sampel
└── README.md
```

---

## 🗄️ Struktur Database

**Database:** `db_crud`  
**Tabel:** `mahasiswa`

| Kolom       | Tipe           | Keterangan                     |
|-------------|----------------|-------------------------------|
| id          | INT(11)        | Primary Key, Auto Increment    |
| nama        | VARCHAR(100)   | NOT NULL                       |
| nim         | VARCHAR(20)    | NOT NULL, UNIQUE               |
| prodi       | VARCHAR(50)    | NOT NULL                       |
| email       | VARCHAR(100)   | NULL allowed                   |
| created_at  | TIMESTAMP      | Default CURRENT_TIMESTAMP      |

---

## ⚙️ Style mysqli yang Digunakan

Proyek ini menggunakan **OOP Style** (Object-Oriented):

```php
// Membuat objek koneksi
$db = new mysqli('localhost', 'root', '', 'db_crud');

// Cek koneksi
if ($db->connect_error) {
    die("Koneksi gagal: " . $db->connect_error);
}

// Prepared Statement
$stmt = $db->prepare("INSERT INTO mahasiswa (nama, nim) VALUES (?, ?)");
$stmt->bind_param("ss", $nama, $nim);
$stmt->execute();
```

Keunggulan: lebih ringkas, mudah dikembangkan, dan mendukung method chaining.

---

## 🔄 Alur Kerja Aplikasi

1. **Koneksi** → `koneksi.php` diinclude setiap halaman
2. **Read** → `index.php` query SELECT, tampilkan tabel
3. **Create** → `create.php` validasi → prepare INSERT → redirect
4. **Update** → `edit.php` fetch data lama → form pre-filled → prepare UPDATE
5. **Delete** → `delete.php` konfirmasi → prepare DELETE → redirect

---

## 🚀 Cara Menjalankan

1. Install **XAMPP / Laragon**
2. Taruh folder `crud-mysqli-app/` di `htdocs/`
3. Import `database.sql` via **phpMyAdmin**
4. Buka browser: `http://localhost/crud-mysqli-app/`

---

## 🛡️ Keamanan
- Semua query manipulasi menggunakan `prepare()` + `bind_param()` → **anti SQL Injection**
- Input disanitasi dengan `htmlspecialchars()` → **anti XSS**
- Validasi ID dengan `FILTER_VALIDATE_INT` → **anti parameter tampering**
- Pesan error ditampilkan via `connect_error` & `$stmt->error`

---

**Tech Stack:** PHP 8.2 · MySQL 8.0 · Bootstrap 5.3 · Bootstrap Icons
