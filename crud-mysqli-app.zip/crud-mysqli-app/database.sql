-- ============================================
--  database.sql — Setup Database & Tabel
--  Jalankan file ini di phpMyAdmin atau CLI
-- ============================================

CREATE DATABASE IF NOT EXISTS db_crud
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE db_crud;

-- Drop tabel jika sudah ada (untuk reset)
DROP TABLE IF EXISTS mahasiswa;

CREATE TABLE mahasiswa (
  id         INT(11)      NOT NULL AUTO_INCREMENT,
  nama       VARCHAR(100) NOT NULL,
  nim        VARCHAR(20)  NOT NULL UNIQUE,
  prodi      VARCHAR(50)  NOT NULL,
  email      VARCHAR(100) DEFAULT NULL,
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Data Sampel ──
INSERT INTO mahasiswa (nama, nim, prodi, email) VALUES
  ('Budi Santoso',    '20220001', 'Teknik Informatika', 'budi@example.com'),
  ('Sari Dewi',       '20220002', 'Sistem Informasi',   'sari@example.com'),
  ('Eko Prasetyo',    '20220003', 'Teknik Informatika', NULL),
  ('Rina Lestari',    '20220004', 'Sistem Informasi',   'rina@example.com'),
  ('Ahmad Fauzi',     '20220005', 'Ilmu Komputer',      NULL);
